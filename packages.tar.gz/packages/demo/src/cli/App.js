import React from 'react'
import Index from './ui/Index'
import {AppBrowser} from 'miolo-cli-tools'



const App = () => {
  return (
    <AppBrowser>
      <Index/>
    </AppBrowser>
  )
}

export default App


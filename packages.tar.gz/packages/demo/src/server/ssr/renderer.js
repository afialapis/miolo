import React from 'react'
import Index from '../../cli/ui/Index'

const renderer = (ctx) => {
  
  return (
    <Index/>
  )
}

export {renderer}



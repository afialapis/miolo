const crud = require('./crud')
const queries = require('./queries')

module.exports= {
  bodyField: undefined,
  crud,
  queries
}
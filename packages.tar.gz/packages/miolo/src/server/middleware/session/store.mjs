import RedisStore from 'koa-redis'

export default new RedisStore()
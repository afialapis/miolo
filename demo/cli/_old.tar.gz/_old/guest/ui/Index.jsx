import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Page from './layout/Page.jsx'
import Todos from './pages/Todos.jsx'


const Index = () => {

  return (
    <BrowserRouter
      future={{
        v7_startTransition: true,
        v7_relativeSplatPath: true,
      }}
    >
      <Routes> 
        <Route path={'/'} element={<Page/>}>

          <Route index      element={<Todos/>}/>
          <Route path={'*'} element={<Todos/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default Index


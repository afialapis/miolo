import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Page from './layout/Page.mjs'
import Todos from './pages/Todos.mjs'
import { withMioloContext } from '../../../miolo-cli-react.mjs'


const Index = ({fetcher}) => {
  
  fetcher.set_auth({
    username: 'todoer',
    password: 'todoer'
  })

  return (
    <BrowserRouter
      future={{
        v7_startTransition: true,
        v7_relativeSplatPath: true,
      }}
    >
      <Routes> 
        <Route path={'/'} element={<Page/>}>

          <Route index      element={<Todos/>}/>
          <Route path={'*'} element={<Todos/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default withMioloContext(Index)


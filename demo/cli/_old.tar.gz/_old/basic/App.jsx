import React from 'react'
import Index from './ui/Index.jsx'
import {AppBrowser} from '../../miolo-cli-react.mjs'

// Import styles for this application
import './assets/scss/style.scss'

const App = () => {
  return (
    <AppBrowser>
      <Index/>
    </AppBrowser>
  )
}

export default App


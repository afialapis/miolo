const _LOG_ENABLED= false
const _log = (msg) => {
  if (_LOG_ENABLED) {
    console.log(msg)
  }
}

class BrowserCache {
  constructor() {
    if (typeof window == 'object') {
      _log('Cache :: Initing...')
      this.initCache()
      this.initSocket()
    }
  }
  initCache() {
    const Cache = require('./cache')
    this._cache = new Cache(-1, false, new Cache.LocalStorageCacheStorage('versed'))
  }
  initSocket() {
    let self= this
    const io_cli = require('socket.io-client')
    const io = io_cli();

    io.on('connect', function () {
      _log('Cache :: Socket Connected')
    });

    io.on('disconnect', function () {
      _log('Cache :: Socket Disconnected')
    });

    io.on('error', function (data) {
      console.error('Cache :: Socket Error:')
      _log(data)
    });

    io.on('store_updated', function (data) {
      _log('Cache :: Socket received store_updated (' + data + ')')
      //self._cache.clear()
      self._cache.removeItem(data)
    });
  }

  getItem(k) {
    return this._cache.getItem(k)
  }

  setItem(k,v, opt) {
    return this._cache.setItem(k,v, opt)
  }

  removeItem(k) {
    return this._cache.removeItem(k)
  }

  clear() {
    return this._cache.clear()
  }  
}

const browserCache = new BrowserCache()

export default browserCache

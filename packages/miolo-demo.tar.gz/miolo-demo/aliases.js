const path = require('path')

module.exports = {
  cli: path.join(__dirname, "./src/cli"),
  config: path.join(__dirname, "./src/config"),
  server: path.join(__dirname, "./src/server")
}

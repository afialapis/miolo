export default {
  content: [
    "./cli/**/*.{js,jsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
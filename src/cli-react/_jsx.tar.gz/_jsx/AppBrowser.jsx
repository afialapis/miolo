import React from 'react'
// import { BrowserRouter } from 'react-router-dom'
import MioloContextProvider from './MioloContextProvider.jsx'

const AppBrowser = ({children}) => {
  
  return (
    // <BrowserRouter
    //   future={{
    //     v7_startTransition: true,
    //     v7_relativeSplatPath: true,
    //   }}    
    // >
      <MioloContextProvider context={window.__CONTEXT || {}}>
        {children}
      </MioloContextProvider>
    // </BrowserRouter>
  )
}

export default AppBrowser

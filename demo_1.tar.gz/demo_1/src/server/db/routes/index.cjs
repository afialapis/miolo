import crud from './crud'
import queries from './queries/index'

export default {
  bodyField: undefined,
  crud,
  queries
}
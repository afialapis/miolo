export default {
  hostname: 'localhost',
  port: 8001
}
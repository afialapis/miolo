import React from 'react'
import Index from './ui/Index'
import {AppBrowser} from '../../../src/cli-react/index'



const App = () => {
  return (
    <AppBrowser>
      <Index/>
    </AppBrowser>
  )
}

export default App

